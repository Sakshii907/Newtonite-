# Engineering decisions

Context: the app replaces chat/spreadsheet coordination of operational work. The brief stresses
correctness under concurrent use, authorization, history and scale (tens of thousands of active items,
a very large history, hundreds to thousands of simultaneous users). I optimised for a **small system whose
risky behaviours are provably correct**, and left out breadth.

## 1. PostgreSQL as the single source of truth, doing the hard concurrency work

**Decision.** One relational database; correctness rules are expressed as constraints, conditional updates
and transactions rather than application-level locks or in-memory state. The app processes are stateless.

**Why.** The core risks (two people claiming one item, lost updates, duplicate requests, lost
notifications) are all "two things happened at once" problems. A database already solves these atomically
and works across multiple app processes, which in-process locks or caches would not.

**Trade-offs.** Postgres becomes the scaling bottleneck. Mitigations that fit the same design: indexes
shaped to each query (team/status/priority, assignee/status, full-text GIN), keyset pagination, bounded
dashboard queries, a pooled connection set, and later read replicas and time-partitioned history. I chose
not to add Redis/Kafka/Elasticsearch: each is another system to run and keep consistent, and Postgres full-text
search and `SKIP LOCKED` queues cover this scale.

## 2. Concurrent updates: an atomic claim, plus optimistic versioning for edits

**Decision.**
- **Claim** is one statement: `UPDATE ... SET assignee_id = me WHERE id = ? AND assignee_id IS NULL AND status = 'OPEN'`.
  The `WHERE` clause is the lock; exactly one concurrent caller gets a row back, the rest get `409 already_claimed`
  with the current state. A retry by the winner is recognised and returns success.
- **Edits, reassignments and transitions** lock the row (`SELECT ... FOR UPDATE`), and edits require an
  `If-Match: <version>` header. A stale version returns `409` with the *current* item, so the client can reconcile.
  Every change increments `version`.

**Why.** Claim is a "first one wins" race, so a conditional update is the simplest correct tool. Edits are different:
a person edits for minutes, so holding a lock is wrong; instead we detect that their picture is stale and refuse to
silently overwrite someone else's work (the "lost update" problem).

**Trade-offs.** The edit conflict is surfaced to the user rather than auto-merged (field-level merging would be nicer but
is much more complex and easy to get subtly wrong). The version is per item, so two people editing *different* fields
still conflict; acceptable for an operational tool where correctness beats convenience.

## 3. Safe retries: Idempotency-Key stored in the same transaction as the work

**Decision.** Create, transition and comment accept an `Idempotency-Key`. The key row is inserted in the same
transaction as the change; the response is stored with it. A repeat with the same key and body replays the stored
response (`Idempotent-Replay: true`); the same key with a different body is rejected (422). Concurrent duplicates
serialize on the unique index. The UI generates one key per logical action and retries network failures with it.

**Why.** The brief names this exact case: a user unsure whether their request succeeded. Without keys, a retry of
"create" makes a duplicate item, and a retry of "transition" fails confusingly. Storing the key atomically with the
work means there is no window where the work committed but the key was lost.

**Trade-offs.** Failed requests are deliberately *not* cached (their transaction rolls back, freeing the key), so a client
may retry an error. Claim and assign don't need keys because they are naturally idempotent. Keys need a retention job
(not built).

## 4. Authorization at the resource level, enforced on the server; workflow rules in one place

**Decision.** Roles are **per team** (`viewer < member < lead < admin`) stored in `memberships`. Every endpoint resolves the
*item's* team, then calls `authz.require(user, team, action)`. List queries also filter by the caller's teams in SQL, so rows
from other teams are never fetched. Non-members get `404` (not `403`) so item existence isn't leaked. Status changes go
through one rules table in `workflow.py` (e.g. HIGH/URGENT items must pass `NEEDS_APPROVAL`; only a lead can approve;
members can progress only items they own; closed items are read-only). The UI receives `can` and `next_statuses` from the
server only to decide which buttons to show; it is never the enforcement.

**Why.** "Hiding buttons" is not security, and per-team roles match "different responsibilities within teams". Keeping
rules in one table makes the workflow auditable, testable and easy to change.

**Trade-offs.** A fixed role ladder is simple but coarse (no custom per-action permissions, no per-item ACLs, no
cross-team collaborators). There's no caching of memberships, so each request does one small indexed lookup; that is the right
trade for correctness at this scale.

## 5. Append-only history and a transactional outbox for asynchronous work

**Decision.** Every important action writes an `activity_events` row **in the same transaction** as the change, and a database
trigger forbids `UPDATE`/`DELETE` on that table. The same transaction also writes an `outbox` row. A background worker claims
outbox rows with `FOR UPDATE SKIP LOCKED`, creates notifications, and marks the row done. Notifications have `UNIQUE (outbox_id, user_id)`.
Failures retry with exponential backoff and are parked as `DEAD` after 5 attempts.

**Why.** History must never silently disappear, and notifications must neither be lost (change committed, notification not)
nor sent for changes that rolled back. Writing both in the change's transaction gives that guarantee without distributed
transactions. Delivery is at-least-once; the unique key makes the handler idempotent, so a crash or double-run can't duplicate notifications.
Notifying is asynchronous so the user's request never waits on, or fails because of, secondary work.

**Trade-offs.** Notifications are slightly delayed (about a second). Polling the outbox costs a small query per second per worker;
at larger scale I'd use `LISTEN/NOTIFY` or a real queue. The worker is a thread in the API process for simplicity.
History is JSONB payloads, which is flexible but unindexed by content.

## What I intentionally did not build

Real-time push (polling is used; conflicts are still detected on write), email/Slack delivery, SLAs and escalations, attachments,
comment editing, a React/SPA toolchain (a single dependency-free page keeps the focus on behaviour), SSO and refresh tokens, an admin UI
for creating users/teams, and UI automated tests. See "Known limitations" in the README.

## If the application grew significantly

Move the worker to its own process and use `LISTEN/NOTIFY` or a queue; add SSE/WebSockets for live updates; partition `activity_events`
by month and archive old partitions; add read replicas for list/search/dashboard queries; consider a dedicated search index if relevance
or fuzzy matching matters; cache memberships briefly; add rate limiting and proper identity (SSO); add per-item SLA timers and a stale-item sweeper.
