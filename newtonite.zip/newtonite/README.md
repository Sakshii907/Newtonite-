# Newtonite Ops: operational work tracker

An internal web app for coordinating operational work (incidents, payment investigations, approvals)
across teams. Built for the *Newtonite Software Engineering Challenge: Operations Under Pressure*.

**Stack:** Python 3.12 + FastAPI, PostgreSQL 16, plain SQL migrations, a dependency-free single-page UI
(served by the API, so there is no frontend build step), pytest against a real database.

## Run it

Requires Docker Desktop.

```bash
docker compose up --build
```

Open **http://localhost:8000**. On the first start the app creates the schema and loads demo data
(3 teams, 8 users, 3,000 work items). API docs: http://localhost:8000/docs

Demo logins (password `password123` for all):

| User | Roles |
|---|---|
| alice@newtonite.test | admin in Payments, member in Platform |
| bob@newtonite.test | lead in Payments, viewer in Support |
| carol@newtonite.test | member in Payments, lead in Platform |
| dave@newtonite.test | member in Platform and Support |
| erin@newtonite.test | lead in Support, member in Platform |
| frank@newtonite.test | viewer in Platform |
| gina@newtonite.test | member in Support and Payments |
| henry@newtonite.test | admin in Platform and Support |

Try it: open two browsers (or one normal + one private window), log in as two different users in the
same team, and click **Claim** on the same item. One wins; the other gets a clear conflict message.

Reset data: `docker compose down -v && docker compose up --build`.
More items: `docker compose exec api python -m app.seed 20000` (only on an empty DB; reset first).

## Run the tests

```bash
docker compose up -d db
docker compose run --rm api pytest -q
```

Tests use a separate `newtonite_test` database (created automatically) and a real Postgres, because
the behaviours under test (row locks, unique keys, transactions) cannot be faked with mocks.

Without Docker for Python: `cd backend && pip install -r requirements.txt && pytest -q` (needs Postgres on localhost:5432 with user/password/db `newtonite`).

## What is where

```
backend/
  migrations/      001 schema, 002 append-only trigger for history
  app/
    main.py        app setup, startup (migrations, seed, worker thread), serves the UI
    items.py       work-item API: create/list/get/patch/claim/assign/transition/comment/activity
    workflow.py    the status state machine (all workflow rules in one table)
    authz.py       roles, permissions, require() used by every route
    idempotency.py Idempotency-Key handling
    common.py      history + outbox writer (log_event)
    worker.py      outbox worker -> notifications
    routes_misc.py login, dashboard, notifications, team members
    security.py    password hashing + signed tokens
    seed.py        demo data
    static/index.html  the UI
  tests/           automated tests for the risky behaviours
ENGINEERING_DECISIONS.md   the five key decisions and trade-offs
```

## API summary

| Method and path | Purpose |
|---|---|
| POST /auth/login, GET /auth/me | sign in, current user and teams |
| GET /work-items?status=&priority=&assignee=&team_id=&q=&cursor=&limit= | filtered, searchable, cursor-paginated list |
| POST /work-items (Idempotency-Key) | create |
| GET /work-items/{id} | item + your role + what you may do |
| PATCH /work-items/{id} (If-Match: version) | edit; 409 if stale |
| POST /work-items/{id}/claim | atomic take-ownership; 409 if someone else got it |
| POST /work-items/{id}/assign | lead reassigns |
| POST /work-items/{id}/transition (Idempotency-Key) | workflow move, rules enforced server-side |
| POST /work-items/{id}/comments (Idempotency-Key) | comment |
| GET /work-items/{id}/activity?cursor= | full history, newest first |
| GET /dashboard | "what needs attention" sections |
| GET /notifications, POST /notifications/read-all | notifications |
| GET/PUT /teams/{id}/members | list members; admins change roles |

## Known limitations

- **Auth is demo-grade:** signed bearer tokens with an 8-hour expiry, no refresh, no revocation, no login
  rate limiting, no password reset or SSO. `SECRET_KEY` must be set properly in any real deployment.
- **Change propagation is polling (15 s), not push.** Conflicts are still always detected on write; polling
  only affects how soon a user *sees* someone else's change. Next step: Server-Sent Events.
- **Notifications are in-app only** (no email/Slack), and there is no per-user notification preference.
- **Search** is Postgres full-text on title and description; comments are not searched, no fuzzy matching.
- **List ordering is newest-first by id.** Sorting by other columns needs matching composite indexes and
  a compound cursor.
- **The worker runs inside the API process** (a background thread). Fine for one deployment; at scale it
  should be a separate process (the SKIP LOCKED design already allows several).
- **Idempotency keys and old history are never purged.** They need a retention job in production
  (and `activity_events` should be partitioned by time once it reaches hundreds of millions of rows).
- **Admin tooling is minimal:** team admins can change roles of existing users, but there is no UI for
  creating users/teams, and demoting the last admin of a team is not prevented.
- **Members may set the priority when creating an item**, but only leads can change it afterwards.
- **No attachments, SLAs, or editing/deleting of comments.**
- Tests cover the backend behaviours; the UI has no automated tests.
