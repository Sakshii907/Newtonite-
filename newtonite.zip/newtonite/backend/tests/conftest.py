"""Tests run against a REAL Postgres (a separate `newtonite_test` database, created on demand).

Mocking the database would hide exactly the bugs these tests exist to catch (races, locks, unique keys).
"""
import os
from types import SimpleNamespace

import psycopg
import pytest
from psycopg.conninfo import make_conninfo

BASE_URL = os.environ.get("DATABASE_URL", "postgresql://newtonite:newtonite@localhost:5432/newtonite")
TEST_DB = "newtonite_test"
os.environ["DATABASE_URL"] = make_conninfo(BASE_URL, dbname=TEST_DB)
os.environ["DISABLE_WORKER"] = "1"
os.environ["SEED_ON_START"] = "0"

try:
    with psycopg.connect(make_conninfo(BASE_URL, dbname="postgres"), autocommit=True, connect_timeout=5) as c:
        if not c.execute("SELECT 1 FROM pg_database WHERE datname = %s", (TEST_DB,)).fetchone():
            c.execute(f"CREATE DATABASE {TEST_DB}")
except psycopg.OperationalError as exc:
    pytest.exit(f"PostgreSQL not reachable ({exc}). Start it with: docker compose up -d db", returncode=2)

TABLES = "users, teams, memberships, work_items, comments, activity_events, idempotency_keys, outbox, notifications"


@pytest.fixture(scope="session")
def app():
    from fastapi.testclient import TestClient

    from app.main import app as fastapi_app

    with TestClient(fastapi_app):  # runs startup: opens pool, applies migrations
        yield fastapi_app


@pytest.fixture
def client(app):
    from fastapi.testclient import TestClient

    return TestClient(app)


@pytest.fixture
def world(app):
    """Two teams. Team1: lead, m1, m2 (members), viewer. Team2: outsider."""
    from app.db import pool
    from app.security import make_token

    with pool.connection() as conn:
        conn.execute(f"TRUNCATE {TABLES} RESTART IDENTITY CASCADE")
        team1 = conn.execute("INSERT INTO teams (name) VALUES ('T1') RETURNING id").fetchone()["id"]
        team2 = conn.execute("INSERT INTO teams (name) VALUES ('T2') RETURNING id").fetchone()["id"]
        users = {}
        for name, team, role in [("lead", team1, "lead"), ("m1", team1, "member"), ("m2", team1, "member"),
                                 ("viewer", team1, "viewer"), ("outsider", team2, "member")]:
            uid = conn.execute("INSERT INTO users (email, name, password_hash) VALUES (%s, %s, 'x') RETURNING id",
                               (f"{name}@t.test", name)).fetchone()["id"]
            conn.execute("INSERT INTO memberships VALUES (%s, %s, %s)", (uid, team, role))
            users[name] = uid
    return SimpleNamespace(
        team1=team1, team2=team2, users=users,
        h=lambda name, **extra: {"Authorization": f"Bearer {make_token(users[name])}", **extra},
    )


def make_item(client, world, who="m1", **overrides):
    body = {"team_id": world.team1, "title": "Payment stuck", "description": "details", **overrides}
    r = client.post("/work-items", json=body, headers=world.h(who))
    assert r.status_code == 201, r.text
    return r.json()["item"]
