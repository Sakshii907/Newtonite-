"""Each test protects a behaviour that would be dangerous if wrong. See ENGINEERING_DECISIONS.md."""
from concurrent.futures import ThreadPoolExecutor

import psycopg
import pytest
from fastapi.testclient import TestClient

from .conftest import make_item


# 1. Concurrency: two users claim the same item --------------------------------------------
def test_exactly_one_user_wins_a_concurrent_claim(app, world, client):
    item = make_item(client, world)

    def hit(user):
        return user, TestClient(app).post(f"/work-items/{item['id']}/claim", headers=world.h(user)).status_code

    with ThreadPoolExecutor(10) as ex:
        results = [f.result() for f in [ex.submit(hit, u) for u in ["m1", "m2"] * 10]]

    winners = {u for u, code in results if code == 200}
    losers = {u for u, code in results if code == 409}
    assert len(winners) == 1 and winners | losers == {"m1", "m2"}  # one winner, the other always told 409
    after = client.get(f"/work-items/{item['id']}", headers=world.h("lead")).json()["item"]
    assert after["assignee_id"] == world.users[winners.pop()]
    events = client.get(f"/work-items/{item['id']}/activity", headers=world.h("lead")).json()["events"]
    assert sum(e["type"] == "item.assigned" for e in events) == 1  # claim was recorded exactly once


# 2. Stale data: edit based on an old version ------------------------------------------------
def test_stale_edit_is_rejected_with_409_and_does_not_overwrite(client, world):
    item = make_item(client, world)
    v1 = item["version"]
    ok = client.patch(f"/work-items/{item['id']}", json={"title": "A's title"},
                      headers=world.h("m1", **{"If-Match": str(v1)}))
    assert ok.status_code == 200 and ok.json()["item"]["version"] == v1 + 1
    stale = client.patch(f"/work-items/{item['id']}", json={"title": "B's title"},
                         headers=world.h("m2", **{"If-Match": str(v1)}))
    assert stale.status_code == 409
    assert stale.json()["detail"]["current"]["title"] == "A's title"  # client gets the truth to reconcile
    assert client.get(f"/work-items/{item['id']}", headers=world.h("m2")).json()["item"]["title"] == "A's title"


def test_edit_without_version_is_refused(client, world):
    item = make_item(client, world)
    r = client.patch(f"/work-items/{item['id']}", json={"title": "x"}, headers=world.h("m1"))
    assert r.status_code == 428


# 3. Duplicate operations: retrying a request -----------------------------------------------
def test_idempotency_key_prevents_duplicate_create(client, world):
    body = {"team_id": world.team1, "title": "Only once"}
    h = world.h("m1", **{"Idempotency-Key": "abc-123"})
    first = client.post("/work-items", json=body, headers=h)
    second = client.post("/work-items", json=body, headers=h)
    assert first.status_code == second.status_code == 201
    assert first.json()["item"]["id"] == second.json()["item"]["id"]
    assert second.headers.get("idempotent-replay") == "true"
    assert len(client.get("/work-items", headers=world.h("m1")).json()["items"]) == 1


def test_idempotency_key_reuse_with_different_body_is_rejected(client, world):
    h = world.h("m1", **{"Idempotency-Key": "k1"})
    client.post("/work-items", json={"team_id": world.team1, "title": "one"}, headers=h)
    r = client.post("/work-items", json={"team_id": world.team1, "title": "two"}, headers=h)
    assert r.status_code == 422


def test_concurrent_identical_requests_create_one_item(app, world, client):
    body = {"team_id": world.team1, "title": "Racing double-click"}
    headers = world.h("m1", **{"Idempotency-Key": "race-1"})
    with ThreadPoolExecutor(8) as ex:
        codes = [f.result().status_code for f in
                 [ex.submit(lambda: TestClient(app).post("/work-items", json=body, headers=headers)) for _ in range(8)]]
    assert set(codes) == {201}
    assert len(client.get("/work-items", headers=world.h("m1")).json()["items"]) == 1


# 4. Workflow rules --------------------------------------------------------------------------
def transition(client, world, who, item_id, to):
    return client.post(f"/work-items/{item_id}/transition", json={"to_status": to}, headers=world.h(who))


def test_illegal_transitions_are_rejected(client, world):
    item = make_item(client, world)
    assert transition(client, world, "m1", item["id"], "RESOLVED").status_code == 422  # skipping steps
    assert transition(client, world, "m1", item["id"], "IN_PROGRESS").status_code == 422  # nobody owns it yet


def test_urgent_items_need_lead_approval(client, world):
    item = make_item(client, world, priority="URGENT")
    client.post(f"/work-items/{item['id']}/claim", headers=world.h("m1"))
    assert transition(client, world, "m1", item["id"], "IN_PROGRESS").status_code == 200
    assert transition(client, world, "m1", item["id"], "RESOLVED").status_code == 422  # must go via approval
    assert transition(client, world, "m1", item["id"], "NEEDS_APPROVAL").status_code == 200
    assert transition(client, world, "m1", item["id"], "RESOLVED").status_code == 403  # a member can't approve
    assert transition(client, world, "lead", item["id"], "RESOLVED").status_code == 200


def test_only_assignee_or_lead_can_progress_an_item(client, world):
    item = make_item(client, world)
    client.post(f"/work-items/{item['id']}/claim", headers=world.h("m1"))
    assert transition(client, world, "m2", item["id"], "IN_PROGRESS").status_code == 403
    assert transition(client, world, "lead", item["id"], "IN_PROGRESS").status_code == 200


# 5. Resource-level authorization ------------------------------------------------------------
def test_other_teams_cannot_see_or_touch_an_item(client, world):
    item = make_item(client, world)
    h = world.h("outsider")
    assert client.get(f"/work-items/{item['id']}", headers=h).status_code == 404  # existence not leaked
    assert client.post(f"/work-items/{item['id']}/claim", headers=h).status_code == 404
    assert client.get(f"/work-items/{item['id']}/activity", headers=h).status_code == 404
    assert client.get("/work-items", headers=h).json()["items"] == []
    r = client.post("/work-items", json={"team_id": world.team1, "title": "sneaky"}, headers=h)
    assert r.status_code == 403


def test_role_limits_within_a_team(client, world):
    item = make_item(client, world)
    assert client.post(f"/work-items/{item['id']}/claim", headers=world.h("viewer")).status_code == 403
    assert client.get(f"/work-items/{item['id']}", headers=world.h("viewer")).status_code == 200
    v = {"If-Match": str(item["version"])}
    assert client.patch(f"/work-items/{item['id']}", json={"priority": "URGENT"},
                        headers=world.h("m1", **v)).status_code == 403  # members cannot set priority
    assert client.patch(f"/work-items/{item['id']}", json={"priority": "URGENT"},
                        headers=world.h("lead", **v)).status_code == 200
    r = client.post(f"/work-items/{item['id']}/assign", json={"assignee_id": world.users["m2"]},
                    headers=world.h("m1"))
    assert r.status_code == 403


def test_requests_without_valid_token_are_rejected(client, world):
    assert client.get("/work-items").status_code == 401
    assert client.get("/work-items", headers={"Authorization": "Bearer garbage"}).status_code == 401


# 6. History is append-only and complete -------------------------------------------------------
def test_history_records_actions_and_cannot_be_edited(client, world):
    from app.db import pool

    item = make_item(client, world)
    client.post(f"/work-items/{item['id']}/claim", headers=world.h("m1"))
    transition(client, world, "m1", item["id"], "IN_PROGRESS")
    client.post(f"/work-items/{item['id']}/comments", json={"body": "looking into it"}, headers=world.h("m1"))
    types = [e["type"] for e in client.get(f"/work-items/{item['id']}/activity", headers=world.h("m1")).json()["events"]]
    assert types == ["item.commented", "item.transitioned", "item.assigned", "item.created"]
    with pool.connection() as conn, pytest.raises(psycopg.errors.RaiseException):
        conn.execute("DELETE FROM activity_events")


# 7. Async processing: retries, duplicates, failures -------------------------------------------
def count(sql, *params):
    from app.db import pool

    with pool.connection() as conn:
        return conn.execute(sql, params).fetchone()["n"]


def test_worker_creates_notifications_once_even_if_it_runs_twice(client, world):
    from app.db import pool
    from app.worker import process_batch

    item = make_item(client, world)
    client.post(f"/work-items/{item['id']}/assign", json={"assignee_id": world.users["m2"]}, headers=world.h("lead"))
    process_batch()
    assert count("SELECT count(*) AS n FROM notifications WHERE user_id = %s", world.users["m2"]) == 1
    with pool.connection() as conn:  # simulate "worker crashed before marking the row DONE"
        conn.execute("UPDATE outbox SET status = 'PENDING', run_at = now()")
    process_batch()
    assert count("SELECT count(*) AS n FROM notifications WHERE user_id = %s", world.users["m2"]) == 1


def test_failed_processing_is_retried_then_parked(client, world, monkeypatch):
    from app import worker
    from app.db import pool

    make_item(client, world)

    def boom(conn, ev):
        raise RuntimeError("downstream is down")

    monkeypatch.setattr(worker, "handle", boom)
    worker.process_batch()
    with pool.connection() as conn:
        row = conn.execute("SELECT status, attempts, run_at > now() AS delayed FROM outbox").fetchone()
        assert row["status"] == "PENDING" and row["attempts"] == 1 and row["delayed"]  # backoff, not a hot loop
        conn.execute("UPDATE outbox SET attempts = %s, run_at = now()", (worker.MAX_ATTEMPTS - 1,))
    worker.process_batch()
    assert count("SELECT count(*) AS n FROM outbox WHERE status = 'DEAD'") == 1  # parked for inspection


# 8. Pagination --------------------------------------------------------------------------------
def test_cursor_pagination_has_no_gaps_or_duplicates(client, world):
    ids = [make_item(client, world, title=f"item {i}")["id"] for i in range(7)]
    seen, cursor = [], None
    while True:
        url = "/work-items?limit=3" + (f"&cursor={cursor}" if cursor else "")
        page = client.get(url, headers=world.h("m1")).json()
        seen += [i["id"] for i in page["items"]]
        cursor = page["next_cursor"]
        if not cursor:
            break
    assert seen == sorted(ids, reverse=True)


def test_search_and_filters(client, world):
    make_item(client, world, title="Refund for customer", priority="HIGH")
    make_item(client, world, title="Database failover", priority="LOW")
    h = world.h("m1")
    assert [i["title"] for i in client.get("/work-items?q=refund", headers=h).json()["items"]] == ["Refund for customer"]
    assert len(client.get("/work-items?priority=LOW", headers=h).json()["items"]) == 1
    assert len(client.get("/work-items?assignee=none", headers=h).json()["items"]) == 2
