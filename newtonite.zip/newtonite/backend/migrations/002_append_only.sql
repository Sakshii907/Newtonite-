-- History must never be edited or deleted, even by buggy application code.
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'activity_events is append-only';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER activity_events_append_only
    BEFORE UPDATE OR DELETE ON activity_events
    FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
