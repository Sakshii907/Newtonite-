-- Newtonite initial schema

CREATE TABLE users (
    id            BIGSERIAL PRIMARY KEY,
    email         TEXT UNIQUE NOT NULL,
    name          TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE teams (
    id   BIGSERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL
);

-- Role is per team: a user can be a lead in one team and a viewer in another.
CREATE TABLE memberships (
    user_id BIGINT NOT NULL REFERENCES users(id),
    team_id BIGINT NOT NULL REFERENCES teams(id),
    role    TEXT NOT NULL CHECK (role IN ('viewer', 'member', 'lead', 'admin')),
    PRIMARY KEY (user_id, team_id)
);

CREATE TABLE work_items (
    id          BIGSERIAL PRIMARY KEY,
    team_id     BIGINT NOT NULL REFERENCES teams(id),
    title       TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'OPEN'
                CHECK (status IN ('OPEN','IN_PROGRESS','NEEDS_APPROVAL','RESOLVED','CLOSED')),
    priority    TEXT NOT NULL DEFAULT 'MEDIUM'
                CHECK (priority IN ('LOW','MEDIUM','HIGH','URGENT')),
    assignee_id BIGINT REFERENCES users(id),
    created_by  BIGINT NOT NULL REFERENCES users(id),
    due_at      TIMESTAMPTZ,
    version     INTEGER NOT NULL DEFAULT 1,   -- optimistic concurrency token
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    search_vector TSVECTOR GENERATED ALWAYS AS (
        to_tsvector('english', coalesce(title,'') || ' ' || coalesce(description,''))
    ) STORED
);

CREATE INDEX idx_wi_team_status_prio ON work_items (team_id, status, priority);
CREATE INDEX idx_wi_assignee_status  ON work_items (assignee_id, status);
CREATE INDEX idx_wi_created_id       ON work_items (created_at DESC, id DESC);
CREATE INDEX idx_wi_search           ON work_items USING GIN (search_vector);

CREATE TABLE comments (
    id           BIGSERIAL PRIMARY KEY,
    work_item_id BIGINT NOT NULL REFERENCES work_items(id),
    author_id    BIGINT NOT NULL REFERENCES users(id),
    body         TEXT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_comments_item ON comments (work_item_id, created_at);

-- Append-only history. Never UPDATE or DELETE rows here.
CREATE TABLE activity_events (
    id           BIGSERIAL PRIMARY KEY,
    work_item_id BIGINT NOT NULL REFERENCES work_items(id),
    actor_id     BIGINT NOT NULL REFERENCES users(id),
    type         TEXT NOT NULL,
    payload      JSONB NOT NULL DEFAULT '{}',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_events_item ON activity_events (work_item_id, id DESC);

-- Stores the result of a request so a retry returns the same response.
CREATE TABLE idempotency_keys (
    key           TEXT NOT NULL,
    user_id       BIGINT NOT NULL REFERENCES users(id),
    request_hash  TEXT NOT NULL,
    response_code INTEGER,
    response_body JSONB,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, key)
);

-- Transactional outbox: written in the same transaction as the change.
CREATE TABLE outbox (
    id         BIGSERIAL PRIMARY KEY,
    event_type TEXT NOT NULL,
    payload    JSONB NOT NULL,
    status     TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','DONE','DEAD')),
    attempts   INTEGER NOT NULL DEFAULT 0,
    run_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_outbox_pending ON outbox (run_at) WHERE status = 'PENDING';

CREATE TABLE notifications (
    id           BIGSERIAL PRIMARY KEY,
    user_id      BIGINT NOT NULL REFERENCES users(id),
    work_item_id BIGINT REFERENCES work_items(id),
    outbox_id    BIGINT REFERENCES outbox(id),
    message      TEXT NOT NULL,
    read_at      TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (outbox_id, user_id)   -- makes the worker idempotent if it runs twice
);
CREATE INDEX idx_notif_user ON notifications (user_id, created_at DESC);
