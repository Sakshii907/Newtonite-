from fastapi import Header, HTTPException

from .db import pool
from .security import read_token


def current_user(authorization: str = Header(default="")):
    """Authentication: who is calling? (Authorization is in authz.py.)"""
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Not authenticated")
    uid = read_token(authorization[7:])
    if uid is None:
        raise HTTPException(401, "Invalid or expired token")
    with pool.connection() as conn:
        user = conn.execute("SELECT id, email, name FROM users WHERE id = %s", (uid,)).fetchone()
    if not user:
        raise HTTPException(401, "Unknown user")
    return user
