from datetime import datetime
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field

from .authz import allowed_actions, can, get_role, require
from .common import VIEW_SELECT, log_event
from .db import pool
from .deps import current_user
from .idempotency import run_idempotent
from .workflow import PRIORITIES, STATUSES, check_transition, next_statuses

router = APIRouter(prefix="/work-items", tags=["work-items"])

Priority = Literal["LOW", "MEDIUM", "HIGH", "URGENT"]
Status = Literal["OPEN", "IN_PROGRESS", "NEEDS_APPROVAL", "RESOLVED", "CLOSED"]


class CreateItem(BaseModel):
    team_id: int
    title: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=10000)
    priority: Priority = "MEDIUM"
    due_at: Optional[datetime] = None


class PatchItem(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = Field(default=None, max_length=10000)
    priority: Optional[Priority] = None
    due_at: Optional[datetime] = None


class AssignBody(BaseModel):
    assignee_id: Optional[int] = None


class TransitionBody(BaseModel):
    to_status: Status


class CommentBody(BaseModel):
    body: str = Field(min_length=1, max_length=5000)


# ---------- helpers ----------

def parse_version(value: Optional[str], required: bool) -> Optional[int]:
    if value is None:
        if required:
            raise HTTPException(428, "If-Match header with the item's current version is required")
        return None
    try:
        return int(value.strip().strip('"'))
    except ValueError:
        raise HTTPException(400, "If-Match must be the integer item version")


def team_of(conn, item_id: int) -> int:
    row = conn.execute("SELECT team_id FROM work_items WHERE id = %s", (item_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Work item not found")
    return row["team_id"]


def view(conn, item_id: int) -> dict:
    return conn.execute(VIEW_SELECT + " WHERE w.id = %s", (item_id,)).fetchone()


def detail(conn, user, item_id: int) -> dict:
    item = view(conn, item_id)
    role = get_role(conn, user["id"], item["team_id"])
    return {
        "item": item,
        "role": role,
        "can": allowed_actions(role),
        "next_statuses": next_statuses(item, role, user["id"]),
    }


def lock_item(conn, user, item_id: int, action: str):
    """Authorize against the item's team, then take a row lock so concurrent writers queue up."""
    team_id = team_of(conn, item_id)
    role = require(conn, user, team_id, action)
    item = conn.execute(
        "SELECT id, team_id, status, priority, assignee_id, title, description, due_at, version "
        "FROM work_items WHERE id = %s FOR UPDATE",
        (item_id,),
    ).fetchone()
    return item, role


def check_version(conn, item: dict, expected: Optional[int]) -> None:
    if expected is not None and item["version"] != expected:
        raise HTTPException(409, detail={
            "code": "version_conflict",
            "message": "This item was changed by someone else. The latest version has been loaded.",
            "current": jsonable_encoder(view(conn, item["id"])),
        })


# ---------- endpoints ----------

@router.post("", status_code=201)
def create_item(body: CreateItem, user=Depends(current_user),
                idempotency_key: Optional[str] = Header(default=None)):
    def work(conn):
        require(conn, user, body.team_id, "create", hide=False)
        row = conn.execute(
            "INSERT INTO work_items (team_id, title, description, priority, due_at, created_by) "
            "VALUES (%s, %s, %s, %s, %s, %s) RETURNING id",
            (body.team_id, body.title, body.description, body.priority, body.due_at, user["id"]),
        ).fetchone()
        log_event(conn, row["id"], user["id"], "item.created",
                  {"title": body.title, "priority": body.priority})
        return 201, detail(conn, user, row["id"])

    return run_idempotent(user["id"], idempotency_key,
                          {"scope": "create", **body.model_dump(mode="json")}, work)


@router.get("")
def list_items(
    user=Depends(current_user),
    status: Optional[str] = None,
    priority: Optional[str] = None,
    assignee: Optional[str] = Query(default=None, description="'me', 'none' or a user id"),
    team_id: Optional[int] = None,
    q: Optional[str] = Query(default=None, max_length=200),
    cursor: Optional[int] = None,
    limit: int = Query(25, ge=1, le=100),
):
    # Visibility is enforced in SQL: only items from the caller's teams can ever be returned.
    where = ["w.team_id IN (SELECT team_id FROM memberships WHERE user_id = %s)"]
    params: list = [user["id"]]
    if status:
        vals = status.split(",")
        if any(v not in STATUSES for v in vals):
            raise HTTPException(422, "Unknown status")
        where.append("w.status = ANY(%s)")
        params.append(vals)
    if priority:
        vals = priority.split(",")
        if any(v not in PRIORITIES for v in vals):
            raise HTTPException(422, "Unknown priority")
        where.append("w.priority = ANY(%s)")
        params.append(vals)
    if assignee == "me":
        where.append("w.assignee_id = %s")
        params.append(user["id"])
    elif assignee == "none":
        where.append("w.assignee_id IS NULL")
    elif assignee:
        if not assignee.isdigit():
            raise HTTPException(422, "assignee must be 'me', 'none' or a user id")
        where.append("w.assignee_id = %s")
        params.append(int(assignee))
    if team_id:
        where.append("w.team_id = %s")
        params.append(team_id)
    if q:
        where.append("w.search_vector @@ websearch_to_tsquery('english', %s)")
        params.append(q)
    if cursor:
        where.append("w.id < %s")  # keyset pagination: cost does not grow with page depth
        params.append(cursor)
    sql = f"{VIEW_SELECT} WHERE {' AND '.join(where)} ORDER BY w.id DESC LIMIT %s"
    params.append(limit + 1)
    with pool.connection() as conn:
        rows = conn.execute(sql, params).fetchall()
    has_more = len(rows) > limit
    rows = rows[:limit]
    return {"items": rows, "next_cursor": rows[-1]["id"] if has_more else None}


@router.get("/{item_id}")
def get_item(item_id: int, user=Depends(current_user)):
    with pool.connection() as conn:
        require(conn, user, team_of(conn, item_id), "read")
        return detail(conn, user, item_id)


@router.patch("/{item_id}")
def patch_item(item_id: int, body: PatchItem, user=Depends(current_user),
               if_match: Optional[str] = Header(default=None)):
    """Optimistic concurrency: the client sends the version it saw; a stale version gets 409."""
    expected = parse_version(if_match, required=True)
    with pool.connection() as conn:
        item, role = lock_item(conn, user, item_id, "edit")
        check_version(conn, item, expected)
        if item["status"] == "CLOSED":
            raise HTTPException(422, "Closed items are read-only; reopen the item first")
        changes = {}
        for f in ("title", "description", "priority", "due_at"):
            if f not in body.model_fields_set:
                continue
            new = getattr(body, f)
            if new is None and f != "due_at":
                continue
            if new != item[f]:
                changes[f] = new
        if "priority" in changes and not can(role, "set_priority"):
            raise HTTPException(403, f"Your role '{role}' is not allowed to set priority")
        if changes:
            sets = ", ".join(f"{f} = %s" for f in changes)  # keys come from the whitelist above
            conn.execute(
                f"UPDATE work_items SET {sets}, version = version + 1, updated_at = now() WHERE id = %s",
                [*changes.values(), item_id],
            )
            log_event(conn, item_id, user["id"], "item.updated",
                      {"changes": {f: [item[f], v] for f, v in changes.items()}})
        return detail(conn, user, item_id)


@router.post("/{item_id}/claim")
def claim_item(item_id: int, user=Depends(current_user)):
    """Atomic claim. The conditional UPDATE is the lock: exactly one concurrent caller wins."""
    with pool.connection() as conn:
        require(conn, user, team_of(conn, item_id), "claim")
        won = conn.execute(
            "UPDATE work_items SET assignee_id = %s, version = version + 1, updated_at = now() "
            "WHERE id = %s AND assignee_id IS NULL AND status = 'OPEN' RETURNING id",
            (user["id"], item_id),
        ).fetchone()
        if won:
            log_event(conn, item_id, user["id"], "item.assigned",
                      {"assignee_id": user["id"], "assignee_name": user["name"], "via": "claim"})
            return detail(conn, user, item_id)
        cur = view(conn, item_id)
        if cur["assignee_id"] == user["id"]:
            return detail(conn, user, item_id)  # retry of our own successful claim: same result
        if cur["assignee_id"] is not None:
            raise HTTPException(409, detail={
                "code": "already_claimed",
                "message": f"{cur['assignee_name']} already took this item.",
                "current": jsonable_encoder(cur),
            })
        raise HTTPException(422, f"Only OPEN items can be claimed (this one is {cur['status']})")


@router.post("/{item_id}/assign")
def assign_item(item_id: int, body: AssignBody, user=Depends(current_user),
                if_match: Optional[str] = Header(default=None)):
    expected = parse_version(if_match, required=False)
    with pool.connection() as conn:
        item, _ = lock_item(conn, user, item_id, "reassign")
        check_version(conn, item, expected)
        if item["status"] == "CLOSED":
            raise HTTPException(422, "Closed items are read-only")
        name = None
        if body.assignee_id is not None:
            role = get_role(conn, body.assignee_id, item["team_id"])
            if not can(role, "claim"):
                raise HTTPException(422, "Assignee must be a team member who can work on items")
            name = conn.execute("SELECT name FROM users WHERE id = %s", (body.assignee_id,)).fetchone()["name"]
        elif item["status"] in ("IN_PROGRESS", "NEEDS_APPROVAL"):
            raise HTTPException(422, "Cannot unassign an item that is in progress")
        if body.assignee_id != item["assignee_id"]:
            conn.execute(
                "UPDATE work_items SET assignee_id = %s, version = version + 1, updated_at = now() WHERE id = %s",
                (body.assignee_id, item_id),
            )
            log_event(conn, item_id, user["id"], "item.assigned",
                      {"assignee_id": body.assignee_id, "assignee_name": name,
                       "previous_assignee_id": item["assignee_id"], "via": "assign"})
        return detail(conn, user, item_id)


@router.post("/{item_id}/transition")
def transition_item(item_id: int, body: TransitionBody, user=Depends(current_user),
                    if_match: Optional[str] = Header(default=None),
                    idempotency_key: Optional[str] = Header(default=None)):
    expected = parse_version(if_match, required=False)

    def work(conn):
        item, role = lock_item(conn, user, item_id, "transition")
        check_version(conn, item, expected)
        err = check_transition(item, body.to_status, role, user["id"])
        if err:
            raise HTTPException(err[0], err[1])
        conn.execute(
            "UPDATE work_items SET status = %s, version = version + 1, updated_at = now() WHERE id = %s",
            (body.to_status, item_id),
        )
        log_event(conn, item_id, user["id"], "item.transitioned",
                  {"from": item["status"], "to": body.to_status})
        return 200, detail(conn, user, item_id)

    return run_idempotent(user["id"], idempotency_key,
                          {"scope": f"transition:{item_id}", "to": body.to_status, "v": expected}, work)


@router.post("/{item_id}/comments", status_code=201)
def add_comment(item_id: int, body: CommentBody, user=Depends(current_user),
                idempotency_key: Optional[str] = Header(default=None)):
    def work(conn):
        require(conn, user, team_of(conn, item_id), "comment")
        c = conn.execute(
            "INSERT INTO comments (work_item_id, author_id, body) VALUES (%s, %s, %s) RETURNING id",
            (item_id, user["id"], body.body),
        ).fetchone()
        log_event(conn, item_id, user["id"], "item.commented",
                  {"comment_id": c["id"], "body": body.body[:500]})
        return 201, {"id": c["id"]}

    return run_idempotent(user["id"], idempotency_key,
                          {"scope": f"comment:{item_id}", "body": body.body}, work)


@router.get("/{item_id}/activity")
def activity(item_id: int, user=Depends(current_user), cursor: Optional[int] = None,
             limit: int = Query(30, ge=1, le=100)):
    with pool.connection() as conn:
        require(conn, user, team_of(conn, item_id), "read")
        params: list = [item_id]
        cur_sql = ""
        if cursor:
            cur_sql = "AND e.id < %s"
            params.append(cursor)
        params.append(limit + 1)
        rows = conn.execute(
            "SELECT e.id, e.type, e.payload, e.created_at, u.name AS actor_name "
            "FROM activity_events e JOIN users u ON u.id = e.actor_id "
            f"WHERE e.work_item_id = %s {cur_sql} ORDER BY e.id DESC LIMIT %s",
            params,
        ).fetchall()
    has_more = len(rows) > limit
    rows = rows[:limit]
    return {"events": rows, "next_cursor": rows[-1]["id"] if has_more else None}
