"""Authorization: every route calls require() with the *resource's* team. UI hiding is cosmetic."""
from fastapi import HTTPException

RANK = {"viewer": 0, "member": 1, "lead": 2, "admin": 3}

# action -> minimum role (in the team that owns the resource)
MIN_ROLE = {
    "read": "viewer",
    "create": "member",
    "comment": "member",
    "claim": "member",
    "edit": "member",
    "transition": "member",
    "reassign": "lead",
    "set_priority": "lead",
    "manage_members": "admin",
}


def get_role(conn, user_id: int, team_id: int):
    row = conn.execute(
        "SELECT role FROM memberships WHERE user_id = %s AND team_id = %s", (user_id, team_id)
    ).fetchone()
    return row["role"] if row else None


def can(role, action: str) -> bool:
    return role is not None and RANK[role] >= RANK[MIN_ROLE[action]]


def allowed_actions(role) -> list:
    return [a for a in MIN_ROLE if can(role, a)]


def require(conn, user, team_id: int, action: str, hide: bool = True) -> str:
    """Return the caller's role or raise. Non-members get 404 so other teams' items don't leak."""
    role = get_role(conn, user["id"], team_id)
    if role is None:
        if hide:
            raise HTTPException(404, "Not found")
        raise HTTPException(403, "You are not a member of this team")
    if not can(role, action):
        raise HTTPException(403, f"Your role '{role}' is not allowed to {action.replace('_', ' ')}")
    return role
