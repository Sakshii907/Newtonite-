"""The workflow state machine. All status rules live here, enforced server-side."""
from .authz import RANK

STATUSES = ["OPEN", "IN_PROGRESS", "NEEDS_APPROVAL", "RESOLVED", "CLOSED"]
PRIORITIES = ["LOW", "MEDIUM", "HIGH", "URGENT"]

# (from, to) -> minimum role required
RULES = {
    ("OPEN", "IN_PROGRESS"): "member",
    ("IN_PROGRESS", "NEEDS_APPROVAL"): "member",
    ("IN_PROGRESS", "RESOLVED"): "member",  # only LOW/MEDIUM, see check_transition
    ("NEEDS_APPROVAL", "RESOLVED"): "lead",  # approval
    ("NEEDS_APPROVAL", "IN_PROGRESS"): "lead",  # rejection
    ("RESOLVED", "CLOSED"): "member",
    ("RESOLVED", "IN_PROGRESS"): "member",  # reopen
    ("CLOSED", "OPEN"): "lead",
}


def check_transition(item: dict, to: str, role: str, user_id: int):
    """Return None if allowed, else (http_status, message)."""
    frm = item["status"]
    needed = RULES.get((frm, to))
    if needed is None:
        return 422, f"Cannot move an item from {frm} to {to}"
    if RANK[role] < RANK[needed]:
        return 403, f"Moving {frm} to {to} requires the '{needed}' role"
    if frm == "IN_PROGRESS" and to == "RESOLVED" and item["priority"] in ("HIGH", "URGENT"):
        return 422, "HIGH and URGENT items must go through NEEDS_APPROVAL"
    if to == "IN_PROGRESS" and item["assignee_id"] is None:
        return 422, "Assign the item to someone before starting work"
    if RANK[role] < RANK["lead"] and frm in ("OPEN", "IN_PROGRESS") and item["assignee_id"] != user_id:
        return 403, "Only the assignee or a lead can progress this item"
    return None


def next_statuses(item: dict, role: str, user_id: int) -> list:
    return [
        to
        for (frm, to) in RULES
        if frm == item["status"] and check_transition(item, to, role, user_id) is None
    ]
