"""Password hashing (scrypt) and signed stateless tokens, using only the stdlib."""
import base64
import hashlib
import hmac
import json
import os
import time

SECRET = os.environ.get("SECRET_KEY", "dev-secret-change-me").encode()
_N, _R, _P = 2**14, 8, 1


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    h = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P)
    return f"{salt.hex()}:{h.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, h_hex = stored.split(":")
        h = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=_N, r=_R, p=_P)
        return hmac.compare_digest(h.hex(), h_hex)
    except ValueError:
        return False


def _sign(payload: str) -> str:
    return hmac.new(SECRET, payload.encode(), hashlib.sha256).hexdigest()


def make_token(user_id: int, ttl: int = 8 * 3600) -> str:
    raw = json.dumps({"uid": user_id, "exp": int(time.time()) + ttl}).encode()
    payload = base64.urlsafe_b64encode(raw).decode()
    return f"{payload}.{_sign(payload)}"


def read_token(token: str):
    """Return the user id, or None if the token is malformed, forged or expired."""
    try:
        payload, sig = token.split(".")
        if not hmac.compare_digest(sig, _sign(payload)):
            return None
        data = json.loads(base64.urlsafe_b64decode(payload))
        return data["uid"] if data["exp"] > time.time() else None
    except Exception:
        return None
