import os
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from . import items, routes_misc, seed, worker
from .db import pool, run_migrations


@asynccontextmanager
async def lifespan(app: FastAPI):
    pool.open(wait=True, timeout=30)
    run_migrations()
    if os.environ.get("SEED_ON_START", "0") == "1":
        seed.seed_if_empty(int(os.environ.get("SEED_ITEMS", "3000")))
    stop = threading.Event()
    thread = None
    if os.environ.get("DISABLE_WORKER") != "1":
        thread = threading.Thread(target=worker.run_forever, args=(stop,), daemon=True)
        thread.start()
    yield
    stop.set()
    if thread:
        thread.join(timeout=5)
    pool.close()


app = FastAPI(title="Newtonite Ops", lifespan=lifespan)
app.include_router(routes_misc.router)
app.include_router(items.router)


@app.get("/health")
def health():
    with pool.connection() as conn:
        conn.execute("SELECT 1")
    return {"status": "ok"}


# Mounted last so the API routes above take priority; serves the single-page UI at "/".
app.mount("/", StaticFiles(directory=Path(__file__).parent / "static", html=True), name="static")
