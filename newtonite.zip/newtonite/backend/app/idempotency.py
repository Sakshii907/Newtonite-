import hashlib
import json

from fastapi import HTTPException
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from psycopg.types.json import Jsonb

from .db import pool


def run_idempotent(user_id: int, key: str | None, payload: dict, work):
    """Run work(conn) -> (status_code, body) at most once per (user, Idempotency-Key).

    The key row is inserted in the SAME transaction as the work. If two identical requests
    race, the second INSERT blocks on the unique index until the first commits, then sees the
    stored response and replays it. If the work fails, the transaction rolls back, the key is
    released, and the client may retry. Errors are intentionally not cached.
    """
    if key is not None and not (1 <= len(key) <= 200):
        raise HTTPException(400, "Idempotency-Key must be 1-200 characters")
    with pool.connection() as conn:
        digest = None
        if key:
            digest = hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()
            inserted = conn.execute(
                "INSERT INTO idempotency_keys (user_id, key, request_hash) VALUES (%s, %s, %s) "
                "ON CONFLICT DO NOTHING RETURNING key",
                (user_id, key, digest),
            ).fetchone()
            if inserted is None:
                prev = conn.execute(
                    "SELECT request_hash, response_code, response_body FROM idempotency_keys "
                    "WHERE user_id = %s AND key = %s",
                    (user_id, key),
                ).fetchone()
                if prev["request_hash"] != digest:
                    raise HTTPException(422, "Idempotency-Key was already used with a different request")
                return JSONResponse(prev["response_body"], status_code=prev["response_code"],
                                    headers={"Idempotent-Replay": "true"})
        code, body = work(conn)
        body = jsonable_encoder(body)
        if key:
            conn.execute(
                "UPDATE idempotency_keys SET response_code = %s, response_body = %s "
                "WHERE user_id = %s AND key = %s",
                (code, Jsonb(body), user_id, key),
            )
        return JSONResponse(body, status_code=code)
