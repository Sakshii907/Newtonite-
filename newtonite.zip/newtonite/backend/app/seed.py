"""Demo data: 3 teams, 8 users with different per-team roles, and thousands of work items.

Run manually:  python -m app.seed 5000
Or automatically on startup with SEED_ON_START=1 (only if the database has no users yet).
"""
import random
import sys
from datetime import datetime, timedelta, timezone

from .db import pool, run_migrations
from .security import hash_password

PASSWORD = "password123"
TEAMS = ["Payments", "Platform", "Support"]
MEMBERSHIPS = {  # user -> {team: role}
    "alice": {"Payments": "admin", "Platform": "member"},
    "bob": {"Payments": "lead", "Support": "viewer"},
    "carol": {"Payments": "member", "Platform": "lead"},
    "dave": {"Platform": "member", "Support": "member"},
    "erin": {"Support": "lead", "Platform": "member"},
    "frank": {"Platform": "viewer"},
    "gina": {"Support": "member", "Payments": "member"},
    "henry": {"Platform": "admin", "Support": "admin"},
}
SUBJECTS = ["Payment failed", "Refund request", "Chargeback review", "Production incident", "API latency spike",
            "Compliance audit request", "Access approval", "Customer escalation", "Data export", "Invoice mismatch",
            "Login errors", "Webhook retries failing", "Database failover", "Fraud alert", "Vendor onboarding"]
DETAILS = ["for enterprise customer", "in the EU region", "after the latest deploy", "reported by support",
           "needs sign-off from finance", "blocking the release", "affecting checkout", "flagged by monitoring"]


def seed_if_empty(n_items: int = 3000) -> None:
    with pool.connection() as conn:
        if conn.execute("SELECT 1 FROM users LIMIT 1").fetchone():
            return
    seed(n_items)


def seed(n_items: int = 3000) -> None:
    random.seed(42)
    with pool.connection() as conn:
        team_ids = {t: conn.execute("INSERT INTO teams (name) VALUES (%s) RETURNING id", (t,)).fetchone()["id"]
                    for t in TEAMS}
        user_ids = {}
        for u in MEMBERSHIPS:
            user_ids[u] = conn.execute(
                "INSERT INTO users (email, name, password_hash) VALUES (%s, %s, %s) RETURNING id",
                (f"{u}@newtonite.test", u.capitalize(), hash_password(PASSWORD)),
            ).fetchone()["id"]
        workers = {t: [] for t in TEAMS}  # people who can own items in each team
        for u, teams in MEMBERSHIPS.items():
            for t, role in teams.items():
                conn.execute("INSERT INTO memberships (user_id, team_id, role) VALUES (%s, %s, %s)",
                             (user_ids[u], team_ids[t], role))
                if role != "viewer":
                    workers[t].append(user_ids[u])

        now = datetime.now(timezone.utc)
        statuses = random.choices(
            ["OPEN", "IN_PROGRESS", "NEEDS_APPROVAL", "RESOLVED", "CLOSED"], [35, 25, 8, 17, 15], k=n_items)
        with conn.cursor() as cur, cur.copy(
            "COPY work_items (team_id, title, description, status, priority, assignee_id, created_by, "
            "due_at, created_at, updated_at) FROM STDIN"
        ) as copy:
            for status in statuses:
                team = random.choice(TEAMS)
                pool_ = workers[team]
                created = now - timedelta(days=random.uniform(0, 90))
                updated = created + (now - created) * random.random()
                assignee = None
                if status != "OPEN" or random.random() < 0.15:
                    assignee = random.choice(pool_)
                due = now + timedelta(days=random.uniform(-10, 20)) if random.random() < 0.5 else None
                title = f"{random.choice(SUBJECTS)} {random.choice(DETAILS)}"
                copy.write_row((team_ids[team], title, f"{title}. Ticket opened via the old chat workflow.",
                                status, random.choices(["LOW", "MEDIUM", "HIGH", "URGENT"], [25, 45, 20, 10])[0],
                                assignee, random.choice(pool_), due, created, updated))
        conn.execute("INSERT INTO activity_events (work_item_id, actor_id, type, payload, created_at) "
                     "SELECT id, created_by, 'item.created', '{}'::jsonb, created_at FROM work_items")
    print(f"Seeded {n_items} items. Log in as <name>@newtonite.test / {PASSWORD}")


if __name__ == "__main__":
    pool.open(wait=True, timeout=30)
    run_migrations()
    seed(int(sys.argv[1]) if len(sys.argv) > 1 else 3000)
    pool.close()
