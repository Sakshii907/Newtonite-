from fastapi.encoders import jsonable_encoder
from psycopg.types.json import Jsonb

VIEW_SELECT = (
    "SELECT w.id, w.team_id, w.title, w.description, w.status, w.priority, w.assignee_id, "
    "a.name AS assignee_name, w.created_by, c.name AS created_by_name, w.due_at, w.version, "
    "w.created_at, w.updated_at "
    "FROM work_items w LEFT JOIN users a ON a.id = w.assignee_id "
    "JOIN users c ON c.id = w.created_by"
)


def log_event(conn, item_id: int, actor_id: int, type_: str, payload: dict | None = None) -> None:
    """Record history AND queue side effects, in the caller's transaction.

    The history row and the outbox row commit (or roll back) together with the change itself,
    so we can never have a change without history, or a notification for a change that failed.
    """
    payload = jsonable_encoder(payload or {})
    ev = conn.execute(
        "INSERT INTO activity_events (work_item_id, actor_id, type, payload) "
        "VALUES (%s, %s, %s, %s) RETURNING id",
        (item_id, actor_id, type_, Jsonb(payload)),
    ).fetchone()
    conn.execute(
        "INSERT INTO outbox (event_type, payload) VALUES (%s, %s)",
        (type_, Jsonb({**payload, "work_item_id": item_id, "actor_id": actor_id, "event_id": ev["id"]})),
    )
