from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from .authz import require
from .common import VIEW_SELECT
from .db import pool
from .deps import current_user
from .security import make_token, verify_password

router = APIRouter()


def teams_of(conn, user_id: int) -> list:
    return conn.execute(
        "SELECT t.id, t.name, m.role FROM memberships m JOIN teams t ON t.id = m.team_id "
        "WHERE m.user_id = %s ORDER BY t.name",
        (user_id,),
    ).fetchall()


class LoginBody(BaseModel):
    email: str
    password: str


@router.post("/auth/login", tags=["auth"])
def login(body: LoginBody):
    with pool.connection() as conn:
        u = conn.execute(
            "SELECT id, email, name, password_hash FROM users WHERE lower(email) = lower(%s)",
            (body.email,),
        ).fetchone()
        if not u or not verify_password(body.password, u["password_hash"]):
            raise HTTPException(401, "Invalid email or password")
        return {
            "token": make_token(u["id"]),
            "user": {"id": u["id"], "email": u["email"], "name": u["name"]},
            "teams": teams_of(conn, u["id"]),
        }


@router.get("/auth/me", tags=["auth"])
def me(user=Depends(current_user)):
    with pool.connection() as conn:
        return {"user": user, "teams": teams_of(conn, user["id"])}


@router.get("/teams/{team_id}/members", tags=["teams"])
def team_members(team_id: int, user=Depends(current_user)):
    with pool.connection() as conn:
        require(conn, user, team_id, "read")
        return conn.execute(
            "SELECT u.id, u.name, m.role FROM memberships m JOIN users u ON u.id = m.user_id "
            "WHERE m.team_id = %s ORDER BY u.name",
            (team_id,),
        ).fetchall()


class RoleBody(BaseModel):
    role: Literal["viewer", "member", "lead", "admin"]


@router.put("/teams/{team_id}/members/{target_id}", tags=["teams"])
def set_member_role(team_id: int, target_id: int, body: RoleBody, user=Depends(current_user)):
    with pool.connection() as conn:
        require(conn, user, team_id, "manage_members")
        if target_id == user["id"]:
            raise HTTPException(422, "You cannot change your own role")
        if not conn.execute("SELECT 1 FROM users WHERE id = %s", (target_id,)).fetchone():
            raise HTTPException(404, "User not found")
        conn.execute(
            "INSERT INTO memberships (user_id, team_id, role) VALUES (%s, %s, %s) "
            "ON CONFLICT (user_id, team_id) DO UPDATE SET role = EXCLUDED.role",
            (target_id, team_id, body.role),
        )
        return {"user_id": target_id, "team_id": team_id, "role": body.role}


@router.get("/dashboard", tags=["dashboard"])
def dashboard(user=Depends(current_user)):
    """'What needs my attention?' Each section is a bounded, indexed query: no full scans in Python."""
    uid = user["id"]
    mine = "w.team_id IN (SELECT team_id FROM memberships WHERE user_id = %s)"
    leads = "w.team_id IN (SELECT team_id FROM memberships WHERE user_id = %s AND role IN ('lead','admin'))"
    sections = {
        "assigned_to_me": (f"{mine} AND w.assignee_id = %s AND w.status IN ('OPEN','IN_PROGRESS','NEEDS_APPROVAL')", [uid, uid]),
        "awaiting_my_approval": (f"{leads} AND w.status = 'NEEDS_APPROVAL'", [uid]),
        "unassigned_urgent": (f"{mine} AND w.assignee_id IS NULL AND w.status = 'OPEN' AND w.priority IN ('HIGH','URGENT')", [uid]),
        "overdue": (f"{mine} AND w.due_at < now() AND w.status NOT IN ('RESOLVED','CLOSED')", [uid]),
        "stale": (f"{mine} AND w.status IN ('OPEN','IN_PROGRESS') AND w.updated_at < now() - interval '3 days'", [uid]),
    }
    order = ("ORDER BY CASE w.priority WHEN 'URGENT' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END, "
             "w.due_at NULLS LAST, w.id DESC LIMIT 8")
    out = {}
    with pool.connection() as conn:
        for name, (where, params) in sections.items():
            count = conn.execute(f"SELECT count(*) AS n FROM work_items w WHERE {where}", params).fetchone()["n"]
            items = conn.execute(f"{VIEW_SELECT} WHERE {where} {order}", params).fetchall()
            out[name] = {"count": count, "items": items}
    return out


@router.get("/notifications", tags=["notifications"])
def notifications(user=Depends(current_user), unread_only: bool = False, limit: int = Query(20, ge=1, le=100)):
    with pool.connection() as conn:
        rows = conn.execute(
            "SELECT id, work_item_id, message, read_at, created_at FROM notifications "
            "WHERE user_id = %s AND (%s = FALSE OR read_at IS NULL) ORDER BY id DESC LIMIT %s",
            (user["id"], unread_only, limit),
        ).fetchall()
        unread = conn.execute(
            "SELECT count(*) AS n FROM notifications WHERE user_id = %s AND read_at IS NULL", (user["id"],)
        ).fetchone()["n"]
    return {"unread": unread, "items": rows}


@router.post("/notifications/read-all", tags=["notifications"])
def read_all(user=Depends(current_user)):
    with pool.connection() as conn:
        conn.execute("UPDATE notifications SET read_at = now() WHERE user_id = %s AND read_at IS NULL", (user["id"],))
    return {"ok": True}


@router.post("/notifications/{notification_id}/read", tags=["notifications"])
def read_one(notification_id: int, user=Depends(current_user)):
    with pool.connection() as conn:
        conn.execute(
            "UPDATE notifications SET read_at = now() WHERE id = %s AND user_id = %s AND read_at IS NULL",
            (notification_id, user["id"]),
        )
    return {"ok": True}
