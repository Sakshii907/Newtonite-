"""Outbox worker: turns committed events into notifications, reliably.

Guarantees (at-least-once delivery + idempotent handler = effectively once):
- Rows are claimed with FOR UPDATE SKIP LOCKED, so several workers never process the same row.
- If the worker crashes mid-batch, the row lock is released and the row is picked up again.
- Notifications have UNIQUE (outbox_id, user_id), so re-processing cannot create duplicates.
- Failures retry with exponential backoff; after MAX_ATTEMPTS the row is parked as DEAD.
"""
import logging
import threading
import time

from .db import pool

log = logging.getLogger("worker")
MAX_ATTEMPTS = 5


def handle(conn, ev: dict) -> None:
    p = ev["payload"]
    item = conn.execute(
        "SELECT id, team_id, title, assignee_id, created_by FROM work_items WHERE id = %s",
        (p["work_item_id"],),
    ).fetchone()
    if not item:
        return
    actor = conn.execute("SELECT name FROM users WHERE id = %s", (p["actor_id"],)).fetchone()["name"]
    kind = ev["event_type"]
    to_notify, text = set(), None
    if kind == "item.assigned" and p.get("assignee_id"):
        to_notify.add(p["assignee_id"])
        text = f"{actor} assigned this item to you"
    elif kind == "item.transitioned" and p.get("to") == "NEEDS_APPROVAL":
        rows = conn.execute(
            "SELECT user_id FROM memberships WHERE team_id = %s AND role IN ('lead','admin')",
            (item["team_id"],),
        ).fetchall()
        to_notify |= {r["user_id"] for r in rows}
        text = f"{actor} needs your approval"
    elif kind == "item.transitioned":
        to_notify |= {item["assignee_id"], item["created_by"]}
        text = f"{actor} moved it to {p['to']}"
    elif kind == "item.commented":
        to_notify |= {item["assignee_id"], item["created_by"]}
        text = f"{actor} commented"
    elif kind == "item.updated":
        to_notify |= {item["assignee_id"], item["created_by"]}
        text = f"{actor} updated it"
    to_notify.discard(None)
    to_notify.discard(p["actor_id"])  # never notify people about their own actions
    for uid in to_notify:
        conn.execute(
            "INSERT INTO notifications (user_id, work_item_id, outbox_id, message) VALUES (%s, %s, %s, %s) "
            "ON CONFLICT (outbox_id, user_id) DO NOTHING",
            (uid, item["id"], ev["id"], f"#{item['id']} {item['title']}: {text}"),
        )


def process_batch(limit: int = 20) -> int:
    processed = 0
    with pool.connection() as conn:
        rows = conn.execute(
            "SELECT id, event_type, payload, attempts FROM outbox "
            "WHERE status = 'PENDING' AND run_at <= now() ORDER BY id LIMIT %s FOR UPDATE SKIP LOCKED",
            (limit,),
        ).fetchall()
        for ev in rows:
            try:
                with conn.transaction():  # savepoint: a failing handler leaves no partial effects
                    handle(conn, ev)
                    conn.execute("UPDATE outbox SET status = 'DONE' WHERE id = %s", (ev["id"],))
                processed += 1
            except Exception:
                attempts = ev["attempts"] + 1
                status = "DEAD" if attempts >= MAX_ATTEMPTS else "PENDING"
                log.exception("outbox %s failed (attempt %s)", ev["id"], attempts)
                conn.execute(
                    "UPDATE outbox SET attempts = %s, status = %s, "
                    "run_at = now() + make_interval(secs => %s) WHERE id = %s",
                    (attempts, status, float(5 * 2 ** attempts), ev["id"]),
                )
    return processed


def run_forever(stop: threading.Event) -> None:
    while not stop.is_set():
        try:
            if process_batch() == 0:
                stop.wait(1.0)
        except Exception:
            log.exception("worker loop error")
            stop.wait(3.0)
